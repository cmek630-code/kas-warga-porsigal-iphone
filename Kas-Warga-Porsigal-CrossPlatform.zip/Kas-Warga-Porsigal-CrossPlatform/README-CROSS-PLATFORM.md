# Kas Warga Porsigal Botoran — Cross-platform preparation

This folder reuses the existing HTML/CSS/JavaScript app and keeps the original visual assets.
It adds a PWA manifest/service worker and a Capacitor configuration as a starting point for a future iOS build.

## Important
- This is a **prepared source project**, not a built APK or IPA.
- The original Android project remains in the parent folder `Kas-Warga-Porsigal/`.
- The app stores records in browser `localStorage`. Data is local to the browser/app installation and is not automatically synced between devices.
- The PWA offline cache only works when hosted over HTTPS (or localhost); opening the HTML directly as a file will not register the service worker.
- A native iOS build still needs an iOS build environment (normally macOS with Xcode) or a compatible cloud build service, plus Apple's signing/provisioning requirements for installing on a physical iPhone.

## Option A — Test as an installable web app
1. Host the contents of this folder on an HTTPS static host (for example, a GitHub Pages site).
2. Open the HTTPS URL on an iPhone in Safari.
3. Use Safari's Share menu and choose **Add to Home Screen**.
4. Test all features and verify local data persistence.

## Option B — Capacitor native build (for a cloud/Mac build environment)
Run from this folder in a Node.js environment:
```bash
npm install
npm install @capacitor/ios
npx cap add ios
npx cap sync ios
```
Then open the iOS project in Xcode on macOS, configure signing, build, and install/distribute using an appropriate Apple-supported route.

For Android in a fresh Capacitor project:
```bash
npm install @capacitor/android
npx cap add android
npx cap sync android
```
This produces a separate Capacitor Android wrapper; it does not replace the original Android project automatically.

## Before daily use
Test the transaction, member, history, settings, offline behavior, and data persistence on target devices. No cross-device backup/sync is included.
